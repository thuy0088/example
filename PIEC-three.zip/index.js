//Vungle

try {
    if (mraid.getState() === "loading") {
        mraid.addEventListener("ready", mraidReadyHandler);
    }
    else {
        mraidReadyHandler();
    }
}
catch (e) {
    if (e.name === "ReferenceError") {
        // mraid is not defined
        window.addEventListener("load", domReadyHandler);
    }
}

var gameIsRunned = false;
function runGame() {
    if(gameIsRunned) return;
    gameIsRunned = true;
    
    Game.init(document.getElementById("vungle-ad"));
    
    Game.app.view.addEventListener("mousedown", GameEvents.interact, false);
    Game.app.view.addEventListener("touchstart", GameEvents.interact, false);
    Game.app.ticker.add(GameEvents.tick);

    try {
        initListeners();
        mraid.expand();
    }
    catch (e) {}
    finally {
        LayoutManager.fitLayout();
    }
}

function domReadyHandler() {
    window.removeEventListener("load", domReadyHandler);
    runGame();
}

function mraidReadyHandler() {
    mraid.removeEventListener("ready", mraidReadyHandler);
    console.log("MRAID ready", window.location.href);
    if (mraid.isViewable()) {
        console.log("MRAID not viewable");
        return mraidViewableHandler(true);
    }
    mraid.addEventListener("viewableChange", mraidViewableHandler);
}

function mraidViewableHandler(flag) {
    if (flag) {
        console.log("MRAID viewable", window.location.href);
        mraid.removeEventListener("viewableChange", mraidViewableHandler);
        runGame();
    }
}

function initListeners() {
    window.addEventListener("resize", LayoutManager.fitLayout);
    setInterval(LayoutManager.fitLayout, 100);
    
    mraid.addEventListener("stateChange", function (state) {
        if (state === "expanded") {
            runGame();
            LayoutManager.fitLayout();
        }
    });
    mraid.addEventListener("sizeChange", function () {
        console.log("MRAID sizeChange", arguments);
        LayoutManager.fitLayout();
    });
    mraid.addEventListener("viewableChange", function () {
        console.log("MRAID viewableChange", arguments);
        LayoutManager.fitLayout();
    });
    mraid.addEventListener("error", function () {
        console.log("MRAID error", arguments);
    });
}

var GameEvents = (function(config){

    var timeEvents = {};
    var timeEventsAfterInteraction = {};
    var interactionEvents = {};
    var ctaEvents = [];
    var interactionCount = 0;

    for (var e in config) {
        var evt = config[e];
        if (evt.cta) ctaEvents.push(e);
        if (evt.time && !evt.afterInteraction) timeEvents[e] = evt.time;
        if (evt.time && evt.afterInteraction) timeEventsAfterInteraction[e] = evt.time;
        if (evt.interactions) interactionEvents[e] = evt.interactions;
    }

    var tick = function() {
        var delta = PIXI.ticker.shared.elapsedMS;
        
        for (var e in timeEvents) {
            timeEvents[e] -= delta;
            if (timeEvents[e] <= 0) {
                reportEvent(e, ctaEvents.indexOf(e) >= 0);
            }
        }
        
        if(interactionCount > 0) {
            for (e in timeEventsAfterInteraction) {
                timeEventsAfterInteraction[e] -= delta;
                if (timeEventsAfterInteraction[e] <= 0) {
                    reportEvent(e, ctaEvents.indexOf(e) >= 0);
                }
            }
        }
    };

    var interact = function() {
        interactionCount++;
        
        for (var e in interactionEvents) {
            interactionEvents[e]--;
            if (interactionEvents[e] <= 0) {
                reportEvent(e, ctaEvents.indexOf(e) >= 0);
            }
        }
    };

    function reportEvent(name, cta) {
        delete(timeEvents[name]);
        delete(interactionEvents[name]);
        delete(timeEventsAfterInteraction[name]);
        callSDK(name);
        if (cta) {
            callSDK("download");
        }
    }

    return {
        tick: tick,
        interact: interact,
        reportEvent: reportEvent
    };

})(CONFIG.gameEvents);

function callSDK(e) {

   
    if(e === "close" || e === "download") {
        if(window.SoundsManager) {
			SoundsManager.enabled = false;
			SoundsManager.soundsOff();
		}
    }
    
	parent.postMessage(e, "*");
}