var CONFIG = {
    androidUrl: "https://play.google.com",
    appleUrl: "https://itunes.apple.com",

    gameEvents: {
        "interaction-second-15": {time: 15000, afterInteraction: true, cta: false},
        "interaction-30": {interactions: 30, cta: false}
    },

    maxGameTime: {enabled: false, time: 30000},
    maxIdleTime: {enabled: false, time: 10000},
    ctaAfterLevel: {enabled: false, level: 1},
    ctaAfterWin: {enabled: false, time: 1000},
    skipOutro: false,
    
    I18: {
        locale: "en",
        strings: {
            "DOWNLOAD": {
                en: "DOWNLOAD",
                ru: "СКАЧАТЬ"
            },
            "DRAG TO ROTATE": {
                en: "DRAG TO\nROTATE",
                ru: "ПОТАЩИТЕ ДЛЯ\nВРАЩЕНИЯ"
            },
            "SECOND CHANCE?": {
                en: "SECOND\nCHANCE?",
                ru: "ВТОРОЙ\nШАНС?"
            },
            "SCORE": {
                en: "SCORE",
                ru: "СЧЕТ"
            },
            "WELL DONE": {
                en: "WELL DONE!",
                ru: "ОТЛИЧНАЯ \nРАБОТА!"
            },
            "continue...": {
                en: "continue...",
                ru: "продолжить..."
            },
            "COMPLETED": {
                en: "COMPLETED",
                ru: "ЗАКОНЧЕНО"
            },
            "tap to next level": {
                en: "tap to next level",
                ru: "следующий уровень"
            }
        }
    },
    
    fontSizeScale: 1,
    
    application: {
        ballStartSpeed: 9,
        ballVelocityBetweenPlates: 0.15,
        ballPosition: 285,

        introBallVelocity: 0.4,

        restartTimeout: 5000,
        tuneCamera: false,
        camera: {
            position: {x: 0, y: 350, z: 290},
            rotation: {x: -0.57, y: 0, z: 0},
            zoom: 1,
        },
        ballJumpTime: 400,
        ballFallTime: 300,
        secondChanceCount: 2,
        distanceBetweenCircles: 200,
        maxPossibleAmountPlates: 20,
        levels: [
            {
                getPoints: 1,
                sectorColor: 0x84466c,
                badColor: 0xd9546d,
                tubeColor: 0xe1937f,
                ballColor: 0xf86b36,
                backColor: ['#a497c4', '#3b4f7d'],
                finalBoardColor: 0xf86b36,

                invisibleSectors: [
                    [0],
                    [4],
                    [4],
                    [4],
                    [2]

                ],
                badSectors: [
                    [1],
                    [5],
                    [7, 0],
                    [],
                    [],

                    [],
                    []
                ]
            },

            {
                getPoints: 2,
                sectorColor: 0x83a809,
                badColor: 0xf0c71d,
                tubeColor: 0xabe1d1,
                ballColor: 0x766ae2,
                backColor: ['#8bad9e', '#346770'],
                finalBoardColor: 0x766ae2,


                invisibleSectors: [
                    [0, 5],
                    [4, 7],
                    [4, 2],
                    [4, 3],
                    [2,3,4],

                    [5, 0],
                    [6, 2],
                    [7, 0]
                ],
                badSectors: [
                    [1, 2],
                    [5, 6],
                    [7, 0],
                    [1, 2],
                    [0],

                    [4],
                    [1]
                ]
            },
            {
                getPoints: 3,
                sectorColor: 0xc37f4d,
                badColor: 0xFF3A25,
                tubeColor: 0x544d4a,
                ballColor: 0xecedf3,
                finalBoardColor: 0xecedf3,


                backColor: ['#aec392', '#609d92'],

                invisibleSectors: [
                    [4, 5],
                    [2, 7],
                    [1, 6],
                    [4, 0],
                    [2,3,4],

                    [5, 0],
                    [6, 2],
                    [7, 0]
                ],
                badSectors: [
                    [1, 2],
                    [5, 6],
                    [7, 0],
                    [1, 2],
                    [0],

                    [4],
                    [1]
                ]
            }
        ]
    }
};