var CONFIG = {
    "androidUrl": "",
    "appleUrl": "",
    "amazonUrl": "",
    "I18": {
        "locale": "en",
        "strings": {
            "Excellent": {
                "en": "excellent"
            },
            "Bonus": {
                "en": "combo bonus!"
            },
            "Combo": {
                "en": "x combo!"
            },
            "Download": {
                "en": "DOWNLOAD"
            }
        }
    },
    "domBinds": [],
    "application": {
        "showFPS": false
    },
    "noInteractionTimeout": 10000,
    "enableTapSound": true,
    "enableTutorial": true,
    "enableAutoPlay": true,
    "autoPlayTimeout": 6500,
    "autoPlayStepFrequency": 3000,
    "textStyles": {
        "excellent": {
            "fontSize": 45,
            "fill": [0xe41fc9,0xb344dc],
            "stroke": 0xffffff,
            "strokeThickness": 4,
            "lineJoin": "round",
        },
        "bonus": {
            "fontSize": 35,
            "fill": [0xf5e225,0xffa808],
            "stroke": 0xffffff,
            "strokeThickness": 4
        },
        "combo": {
            "fontSize": 35,
            "fill": [0x91d6e7, 0x00a2e1],
            "stroke": 0xffffff,
            "strokeThickness": 4
        },
        "download": {
            "fontSize": 45,
            "fill": 0xffffff,
            "stroke": 0xbe5400,
            "strokeThickness": 10,
            "lineJoin": "round",
            //dropShadow": true,
            //"dropShadowColor": 0x000000,
            //"dropShadowAlpha": 0.2,
            //"dropShadowAngle": 2.3,
            //"autoFit": true,
            //"autoFitPadding": 20
        }
    },
    // Merge rules - key is equal to the number on the map, value is a texture name.
    "sequence": {
        2: "1",
        3: "2",
        4: "3",
        5: "4",
        6: "5",
        7: "6",
        8: "7",
    },
    "maxType": 8,
    "portraitScale" :1.5,
    "landscapeScale" : 0.8,
    // To win player has to merge 1 object of the following type
    "winCondition": 7,
    //1 is empty land
    //0 is water
    //2-7 objects, 8 is the very top object which you don't want to have at the
    "portraitFieldMap": [
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 1, 1, 0, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 2, 2,6, 1, 1, 1],
        [0, 0, 0, 0, 0, 0, 0, 2, 2, 2, 2, 2, 5, 1],
        [0, 0, 0, 0, 0, 0, 0, 2, 2, 2, 2, 2, 2, 0],
        [0, 0, 0, 0, 0, 0, 0, 0, 2, 2, 2, 2, 2, 0],
        [0, 0, 0, 0, 2, 3, 0, 2, 2, 2, 2, 2, 0, 0],
        [0, 0, 0, 1, 1, 2, 1, 2, 2, 0, 0, 0, 0, 0],
        [0, 0, 5, 1, 1, 1, 2, 3, 2, 0, 0, 0, 0, 0],
        [0, 0, 1, 2, 2, 2, 2, 2, 2, 0, 0, 0, 0,0],
        [0, 0, 1, 4, 2, 2, 2, 2, 2, 0, 0, 0, 0,0],
        [0, 0, 0, 2, 2, 2, 6, 2, 0, 0, 0, 0, 0,0],
        [0, 0, 0, 0, 2, 2, 2, 0, 0, 0, 0, 0, 0,0],
    ],
    "landscapeFieldMap": [
        [0, 0, 5, 1, 0, 0, 0, 0, 2, 2, 0, 0],
        [0, 6, 2, 1, 2, 0, 0, 1, 2, 2, 1, 0],
        [1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
        [1, 1, 2, 2, 3, 2, 2, 2, 1, 2, 2, 1],
        [5, 1, 1, 2, 1, 1, 3, 2, 1, 1, 1, 6],
        [0, 1, 1, 1, 2, 0, 0, 4, 1, 1, 1, 0],
        [0, 0, 1, 1, 0, 0, 0, 0, 1, 6, 0, 0]
    ],
    // Suggested options for tutorial (0 indexed)
    "portraitTutorialSuggestions": {
        start: { row: 5, col: 4},
        end: { row: 5, col: 4 }
    },
    "landscapeTutorialSuggestions": {
        start: { row: 5, col: 4 },
        end: { row: 4, col: 4 }
    },
    /**
     * Offsets are set in % relative to the game width for X and game height for Y,
     * e.g.: Y value of -0.07 means that field will be moved up on the value equal to 7% of the game height.
     */

    "fieldOffsetX": 0,
    "fieldOffsetY": -0.15,

    // Minimal number and maximum nubers of objects to spawn during outro     
    "minOutroObjectsCount": 10,
    "maxOutroObjectsCount": 12,
};