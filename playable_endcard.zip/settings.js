var PiecSettings = PiecSettings || {};
PiecSettings.version = "-";

//========================== General Settings. Timer, ASOI, fonts =============================
PiecSettings.timer = false;
PiecSettings.timerDuration = 6000;
PiecSettings.asoi = true;

PiecSettings.videoOrientation = "landscape";
PiecSettings.orientationLock = "landscape"; //Choose between "portrait", "landscape" and "none"

PiecSettings.fontColor = "#fff";
PiecSettings.fontFamily = "Contemporary"; //Make sure that this font is on the css and that there is a div that uses it. (preload-font div)
PiecSettings.genericFontFamily = "Noto Sans";

// PiecSettings.videoFramerate = 25; //REMOVE if you want to write in seconds.

PiecSettings.initialScript = "intro";
PiecSettings.script = {

    'intro': {
        video: 'video.mp4',
        from: 0.00,
        to: 4.76,
        loop: false,
        autoplay: { script: 'pedal'}, 
    },

    'pedal': {
        video: 'video.mp4',
        from: 4.90,
        to: 4.91,
        loop: true,
        autoplay: { script: 'gp-1', after: 5000, timer: true}, 
        interactions : [ 
		{ from: 4.90, to: 4.91, typeOfInteraction: 'tap', htmlTag: 'interaction-area', onSuccess: 'gp-1'},
        ],
    },



    'gp-1': {
        video: 'video.mp4',
        from: 5.16,
        to: 6.28,
        loop: false,
        autoplay: { script: 'shift-1'}, 
    },

    'shift-1': {
        video: 'video.mp4',
        from: 6.48,
        to: 6.49,
        loop: true,
        autoplay: { script: 'gp-2', after: 5000, timer: true}, 
        interactions : [ 
		{ from: 6.48, to: 6.49, typeOfInteraction: 'tap', htmlTag: 'interaction-area', onSuccess: 'gp-2'},
        ],
    },




    'gp-2': {
        video: 'video.mp4',
        from: 6.68,
        to: 7.92,
        loop: false,
        autoplay: { script: 'shift-2'}, 
    },

    'shift-2': {
        video: 'video.mp4',
        from: 8.12,
        to: 8.13,
        loop: true,
        autoplay: { script: 'gp-3', after: 5000, timer: true}, 
        interactions : [ 
		{ from: 8.12, to: 8.13, typeOfInteraction: 'tap', htmlTag: 'interaction-area', onSuccess: 'gp-3'},
        ],
    },




    'gp-3': {
        video: 'video.mp4',
        from: 8.32,
        to: 11.20,
        loop: false,
        autoplay: { script: 'shift-3'}, 
    },

    'shift-3': {
        video: 'video.mp4',
        from: 11.350,
        to: 11.351,
        loop: true,
        autoplay: { script: 'gp-4', after: 5000, timer: true}, 
		interactions : [ 
		{ from: 11.35, to: 11.351, typeOfInteraction: 'tap', htmlTag: 'interaction-area', onSuccess: 'gp-4'},
        ],
    },



    'gp-4': {
        video: 'video.mp4',
        from: 11.60,
        to: 15.07,
        loop: false,
        autoplay: { script: 'shift-4'}, 
    },

    'shift-4': {
        video: 'video.mp4',
        from: 15.070,
        to: 15.071,
        loop: true,
        autoplay: { script: 'outro', after: 5000, timer: true}, 
        interactions : [ 
		{ from: 15.070, to: 15.071, typeOfInteraction: 'tap', htmlTag: 'interaction-area', onSuccess: 'outro'},
        ],
    },


    'outro': {
        video: 'video.mp4',
        from: 15.08,
   		to: 24.40,
        loop: false,
        hud : [
        { tag: 'cta', at: 15.11, show: true, htmlTag: 'interaction-area'}, 
        ],  
    },


};

//======================================== HUD Elements ========================================
PiecSettings.hudElements = {

'cta': {
    htmlTag: 'interaction-area',
    anchor: { x: 0.5, y: 0.5 },
    type: 'cta',
},

};

//============Variables and Flags used within the Video PIEC script to apply conditions and consequences=================
PiecSettings.variables = {};

//=================================== Collectible Component ====================================
PiecSettings.collectibles = {};

//================================= Mini Games (e.g. projectile) ===============================
PiecSettings.minigames = {};

//===================================== Png Animations =========================================
PiecSettings.pngAnimations = {};

PiecSettings.defaultLang = "en";
PiecSettings.translations = {
    'Download' : {
        en: "Download",
        ja: "ダウンロード",
        ko: "다운로드",
        zh: "下载",
        de: "Download",
        fr: "Télécharger",
        it: "Scarica",
        es: "Descargar",
        pt: "Baixar",
        ca: "Descarregar",
        ru: "Скачать",
        tr: "Indir",
        nl: "Download",
        sv: "Ladda ner",
        id: "Download",
        ro: "Descărcare",
        ar: "تحميل",
        uk: "скачати",
        no: "Nedlasting",
        nb: "Nedlasting",
        nn: "Nedlasting",
        he: "הורד",
        ms: "ഡൗൺലോഡ്",
        th: "ดาวน์โหลด",
        pl: "Pobierz",
        be: "спампаваць",
        el: "κατεβάστε",
        bg: "изтегляне",
        da: "Hent",
        sr: "довнлоад",
        kk: "жүктеу",
        vi: "Tải về",
        hr: "zbirka",
        km: "ទាញយក",
        sq: "Shkarko",
        sl: "prenesi",
        lt: "parsisiųsti",
        az: "yükləyin",
        zu: "ukulanda",
        ga: "íoslódáil",
        is: "sækja",
        hu: "Letöltés",
        lv: "lejupielādēt",
        ka: "ჩამოტვირთვა",
        mt: "niżżel",
        et: "lae alla",
        ne: "डाउनलोड",
        bn: "ডাউনলোড",
        eu: "deskargatu",
        fi: "ladata",
        sw: "kupakua",
    }
}